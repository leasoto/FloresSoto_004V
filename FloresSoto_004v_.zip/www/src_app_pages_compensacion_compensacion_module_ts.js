(self["webpackChunkMyApp"] = self["webpackChunkMyApp"] || []).push([["src_app_pages_compensacion_compensacion_module_ts"],{

/***/ 1679:
/*!*******************************************************************!*\
  !*** ./src/app/pages/compensacion/compensacion-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CompensacionPageRoutingModule": () => (/* binding */ CompensacionPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _compensacion_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./compensacion.page */ 8011);




const routes = [
    {
        path: '',
        component: _compensacion_page__WEBPACK_IMPORTED_MODULE_0__.CompensacionPage
    }
];
let CompensacionPageRoutingModule = class CompensacionPageRoutingModule {
};
CompensacionPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CompensacionPageRoutingModule);



/***/ }),

/***/ 713:
/*!***********************************************************!*\
  !*** ./src/app/pages/compensacion/compensacion.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CompensacionPageModule": () => (/* binding */ CompensacionPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _compensacion_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./compensacion-routing.module */ 1679);
/* harmony import */ var _compensacion_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./compensacion.page */ 8011);







let CompensacionPageModule = class CompensacionPageModule {
};
CompensacionPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _compensacion_routing_module__WEBPACK_IMPORTED_MODULE_0__.CompensacionPageRoutingModule
        ],
        declarations: [_compensacion_page__WEBPACK_IMPORTED_MODULE_1__.CompensacionPage]
    })
], CompensacionPageModule);



/***/ }),

/***/ 8011:
/*!*********************************************************!*\
  !*** ./src/app/pages/compensacion/compensacion.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CompensacionPage": () => (/* binding */ CompensacionPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_compensacion_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./compensacion.page.html */ 8385);
/* harmony import */ var _compensacion_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./compensacion.page.scss */ 5509);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 476);





let CompensacionPage = class CompensacionPage {
    constructor(menuController) {
        this.menuController = menuController;
        this.componentes = [
            {
                icon: 'beer',
                name: 'cerveza',
                redirectTo: '/alert'
            },
            {
                icon: 'beer',
                name: 'cerveza',
                redirectTo: '/action-sheet'
            },
            {
                icon: 'beer',
                name: 'input',
                redirectTo: '/input'
            },
            {
                icon: 'beer',
                name: 'autos',
                redirectTo: '/autos'
            }
        ];
    }
    ngOnInit() {
    }
    mostrarMenu() {
        this.menuController.open('first');
    }
};
CompensacionPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.MenuController }
];
CompensacionPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-compensacion',
        template: _raw_loader_compensacion_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_compensacion_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], CompensacionPage);



/***/ }),

/***/ 5509:
/*!***********************************************************!*\
  !*** ./src/app/pages/compensacion/compensacion.page.scss ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".logo {\n  width: 60%;\n  left: 0;\n  bottom: 0;\n  padding-left: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbXBlbnNhY2lvbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSxVQUFBO0VBQ0EsT0FBQTtFQUNBLFNBQUE7RUFDQSxlQUFBO0FBQUoiLCJmaWxlIjoiY29tcGVuc2FjaW9uLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5sb2dvIHtcblxuICAgIHdpZHRoOiA2MCU7XG4gICAgbGVmdDogMDtcbiAgICBib3R0b206IDA7XG4gICAgcGFkZGluZy1sZWZ0OiAwO1xuICB9Il19 */");

/***/ }),

/***/ 8385:
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/compensacion/compensacion.page.html ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar class=\"ion-toolbar\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaulthref=\"/\" text=\"volver\" color =\"primary\" mode =\"ios\">\n      </ion-back-button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"mostrarMenu()\">\n        <ion-icon slot=\"icon-only\" name=\"menu-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    \n    <ion-img class=\"logo\" src=\"/assets/logo3.jpeg\"></ion-img>\n  </ion-toolbar>\n  \n</ion-header>\n\n\n<ion-content>\n\n\n  <ion-label>Próximamente...</ion-label>\n  <br>\n  <ion-label>Estamos trabajando en la mejor\n     forma de medir el tonelaje CO2, buscando las herramientas\n      y la forma con la que tú y tu empresa contribuir con el Medio Ambiente.</ion-label>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_compensacion_compensacion_module_ts.js.map