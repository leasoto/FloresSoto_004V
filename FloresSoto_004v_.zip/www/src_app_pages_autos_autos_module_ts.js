(self["webpackChunkMyApp"] = self["webpackChunkMyApp"] || []).push([["src_app_pages_autos_autos_module_ts"],{

/***/ 3675:
/*!*****************************************************!*\
  !*** ./src/app/pages/autos/autos-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AutosPageRoutingModule": () => (/* binding */ AutosPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _autos_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./autos.page */ 7498);




const routes = [
    {
        path: '',
        component: _autos_page__WEBPACK_IMPORTED_MODULE_0__.AutosPage
    }
];
let AutosPageRoutingModule = class AutosPageRoutingModule {
};
AutosPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AutosPageRoutingModule);



/***/ }),

/***/ 410:
/*!*********************************************!*\
  !*** ./src/app/pages/autos/autos.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AutosPageModule": () => (/* binding */ AutosPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _autos_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./autos-routing.module */ 3675);
/* harmony import */ var _autos_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./autos.page */ 7498);







let AutosPageModule = class AutosPageModule {
};
AutosPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _autos_routing_module__WEBPACK_IMPORTED_MODULE_0__.AutosPageRoutingModule
        ],
        declarations: [_autos_page__WEBPACK_IMPORTED_MODULE_1__.AutosPage]
    })
], AutosPageModule);



/***/ }),

/***/ 7498:
/*!*******************************************!*\
  !*** ./src/app/pages/autos/autos.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AutosPage": () => (/* binding */ AutosPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_autos_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./autos.page.html */ 8262);
/* harmony import */ var _autos_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./autos.page.scss */ 4373);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 476);





let AutosPage = class AutosPage {
    constructor(menuController) {
        this.menuController = menuController;
        this.componentes = [
            {
                icon: 'beer',
                name: 'inicio',
                redirectTo: '/inicio'
            },
            {
                icon: 'beer',
                name: 'cerveza',
                redirectTo: '/alert'
            },
            {
                icon: 'beer',
                name: 'cerveza',
                redirectTo: '/action-sheet'
            },
            {
                icon: 'beer',
                name: 'input',
                redirectTo: '/input'
            },
            {
                icon: 'beer',
                name: 'autos',
                redirectTo: '/autos'
            }
        ];
    }
    ngOnInit() {
    }
    mostrarMenu() {
        this.menuController.open('first');
    }
};
AutosPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.MenuController }
];
AutosPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-autos',
        template: _raw_loader_autos_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_autos_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AutosPage);



/***/ }),

/***/ 4373:
/*!*********************************************!*\
  !*** ./src/app/pages/autos/autos.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".logo {\n  width: 60%;\n  left: 0;\n  bottom: 0;\n  padding-left: 0;\n}\n\n.ion-toolbar {\n  height: 70px;\n}\n\n.button1 {\n  width: 40px;\n  height: 40px;\n  margin-top: 25px;\n  margin-left: 15px;\n}\n\n.button2 {\n  width: 40px;\n  height: 40px;\n  margin-top: 25px;\n  margin-left: 10px;\n  align-items: center;\n}\n\n.icon2 {\n  width: 120%;\n}\n\n.titulo {\n  font-size: 22px;\n  size: 5%;\n  font-weight: bold;\n  color: green;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF1dG9zLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVJLFVBQUE7RUFDQSxPQUFBO0VBQ0EsU0FBQTtFQUNBLGVBQUE7QUFBSjs7QUFHQTtFQUNJLFlBQUE7QUFBSjs7QUFJRTtFQUVFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQUZKOztBQUtFO0VBRUUsV0FBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7QUFISjs7QUFNRTtFQUNFLFdBQUE7QUFISjs7QUFNQTtFQUNFLGVBQUE7RUFDQSxRQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0FBSEYiLCJmaWxlIjoiYXV0b3MucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmxvZ28ge1xuXG4gICAgd2lkdGg6IDYwJTtcbiAgICBsZWZ0OiAwO1xuICAgIGJvdHRvbTogMDtcbiAgICBwYWRkaW5nLWxlZnQ6IDA7XG4gIH1cblxuLmlvbi10b29sYmFye1xuICAgIGhlaWdodDo3MHB4O1xuICB9XG5cblxuICAuYnV0dG9uMSB7XG5cbiAgICB3aWR0aDogNDBweDtcbiAgICBoZWlnaHQ6IDQwcHg7XG4gICAgbWFyZ2luLXRvcDogMjVweDtcbiAgICBtYXJnaW4tbGVmdDogMTVweDtcbiAgfVxuXG4gIC5idXR0b24yIHtcblxuICAgIHdpZHRoOiA0MHB4O1xuICAgIGhlaWdodDogNDBweDtcbiAgICBtYXJnaW4tdG9wOiAyNXB4O1xuICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIH1cblxuICAuaWNvbjJ7XG4gICAgd2lkdGg6IDEyMCU7XG4gIH1cblxuLnRpdHVsb3tcbiAgZm9udC1zaXplOiAyMnB4O1xuICBzaXplOiA1JTtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGNvbG9yOmdyZWVuXG5cbn1cbiJdfQ== */");

/***/ }),

/***/ 8262:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/autos/autos.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n\n  <ion-toolbar class=\"ion-toolbar\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaulthref=\"/\" text=\"volver\" color =\"primary\" mode =\"ios\">\n      </ion-back-button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"mostrarMenu()\">\n        <ion-icon slot=\"icon-only\" name=\"menu-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-img class=\"logo\" src=\"/assets/logo3.jpeg\"></ion-img>\n  </ion-toolbar>\n\n</ion-header>\n\n<ion-content>\n\n  <ion-row>\n<ion-fab-button class=\"button1\"routerLink = \"/autos\" color=\"light\">\n\n  <ion-img  src=\"/assets/Logo-Mercedes-Benz.png\"></ion-img>\n</ion-fab-button>\n\n<ion-fab-button class=\"button2\"routerLink = \"/autos\" color=\"light\">\n  <ion-img  src=\"/assets/Chevrolet-Logo.png\"></ion-img>\n</ion-fab-button>\n\n<ion-fab-button class=\"button2\"routerLink = \"/autos\" color=\"light\">\n  <ion-img  src=\"/assets/BMW-Logo.png\"></ion-img>\n</ion-fab-button>\n\n<ion-fab-button class=\"button2\"routerLink = \"/autos\" color=\"light\">\n  <ion-img  src=\"/assets/ferrari.png\"></ion-img>\n</ion-fab-button>\n\n<ion-fab-button class=\"button2\"routerLink = \"/autos\" color=\"light\">\n  <ion-icon class=\"co2inicio\"  name=\"add-outline\" ></ion-icon>\n</ion-fab-button>\n</ion-row>\n<p>\n  <center>\n    <ion-label class=\"titulo\"> Últimas novedades en Hibridos</ion-label>\n  </center> \n</p>\n<!-----------primera tarjeta------------>\n  <ion-card>\n    <img src=\"assets/toyotaprius.jpg\"/>\n    <ion-card-content>\n      <ion-card-title>\n        Toyota Prius\n      </ion-card-title>\n      <p>\n        La emisión de CO2 de la versión híbrida es de 79 g/km en todas las opciones; \n        por su lado, la media de gramos por kilómetro en el resto de motores nos daría 108 g/km. \n        Alrededor de un 40% más.\n      </p>\n    </ion-card-content>\n\n    <ion-row no-padding>\n      <ion-col>\n        <button ion-button clear small color=\"danger\" icon-start>\n          <ion-icon name=\"star\"></ion-icon>\n          Favorite\n        </button>\n      </ion-col>\n\n      <ion-col text-right>\n        <button ion-button clear small color=\"danger\" icon-start>\n          <ion-icon name=\"share-social-outline\"></ion-icon>\n          Share\n        </button>\n      </ion-col>\n    </ion-row>\n\n  </ion-card>\n\n\n\n  <!-----------segunda tarjeta------------>\n  <ion-card class=\"cardautos\">\n    <img src=\"assets/hyundaiioniq.jpg\" />\n    <ion-card-content>\n      <ion-card-title>\n        Hyundai Ioniq\n      </ion-card-title>\n      <p>\n        La opción que ofrece Hyundai Motor de México en este sector, desde 2017,\n         es su sedán híbrido Ioniq. Su emisión de CO2 es apenas del 79g/Km,\n          lo que lo ubica en el rango más bajo contaminante entre los vehículos que utilizan\n           combustión interna. Esto se debe a que cuenta con un motor de 1.6 litros, mismo que combina\n            su funcionamiento con el motor eléctrico.\n      </p>\n    </ion-card-content>\n\n    <ion-row no-padding>\n      <ion-col>\n        <button ion-button clear small color=\"danger\" icon-start>\n          <ion-icon name=\"star\"></ion-icon>\n          Favorite\n        </button>\n      </ion-col>\n\n      <ion-col text-right>\n        <button ion-button clear small color=\"danger\" icon-start>\n          <ion-icon name=\"share-social-outline\"></ion-icon>\n          Share\n        </button>\n      </ion-col>\n    </ion-row>\n\n  </ion-card>\n\n\n  <!-----------tercera tarjeta------------>\n  <ion-card>\n    <img src=\"assets/kiaoptima.jpg\"/>\n    <ion-card-content>\n      <ion-card-title>\n        Kia Optima\n      </ion-card-title>\n      <p>\n        El primer modelo híbrido enchufable de Kia puede llegar a recorrer hasta 54 kilómetros sin emisiones, \n        logrando un consumo medio de combustible de 1,6 litros a los 100 kilómetros y unas emisiones de CO2 de 37 g/km.\n      </p>\n    </ion-card-content>\n\n    <ion-row no-padding>\n      <ion-col>\n        <button ion-button clear small color=\"danger\" icon-start>\n          <ion-icon name=\"star\"></ion-icon>\n          Favorite\n        </button>\n      </ion-col>\n\n      <ion-col text-right>\n        <button ion-button clear small color=\"danger\" icon-start>\n          <ion-icon name=\"share-social-outline\"></ion-icon>\n          Share\n        </button>\n      </ion-col>\n    </ion-row>\n\n  </ion-card>\n</ion-content>\n\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_autos_autos_module_ts.js.map