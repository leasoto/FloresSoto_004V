(self["webpackChunkMyApp"] = self["webpackChunkMyApp"] || []).push([["src_app_pages_input_input_module_ts"],{

/***/ 4430:
/*!*****************************************************!*\
  !*** ./src/app/pages/input/input-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InputPageRoutingModule": () => (/* binding */ InputPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _input_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./input.page */ 2438);




const routes = [
    {
        path: '',
        component: _input_page__WEBPACK_IMPORTED_MODULE_0__.InputPage
    }
];
let InputPageRoutingModule = class InputPageRoutingModule {
};
InputPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], InputPageRoutingModule);



/***/ }),

/***/ 7999:
/*!*********************************************!*\
  !*** ./src/app/pages/input/input.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InputPageModule": () => (/* binding */ InputPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _input_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./input-routing.module */ 4430);
/* harmony import */ var _input_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./input.page */ 2438);







let InputPageModule = class InputPageModule {
};
InputPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _input_routing_module__WEBPACK_IMPORTED_MODULE_0__.InputPageRoutingModule
        ],
        declarations: [_input_page__WEBPACK_IMPORTED_MODULE_1__.InputPage]
    })
], InputPageModule);



/***/ }),

/***/ 2438:
/*!*******************************************!*\
  !*** ./src/app/pages/input/input.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InputPage": () => (/* binding */ InputPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_input_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./input.page.html */ 6412);
/* harmony import */ var _input_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./input.page.scss */ 9159);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 476);





let InputPage = class InputPage {
    constructor(alertController) {
        this.alertController = alertController;
        this.usuario = {
            nombre: '',
            apellido: '',
            genero: '',
            fecha: '',
            email: '',
            password: '',
            password2: '',
        };
    }
    showAlert() {
        this.alertController.create({
            header: 'Tu cuenta ha sido creada.',
            subHeader: 'Se ha enviado la información a tu correo.',
            buttons: ['OK']
        }).then(res => {
            res.present();
        });
    }
    ngOnInit() {
    }
    onSubmit() {
        console.log('submit');
        console.log(this.usuario);
    }
    showConfirm() {
        this.alertController.create({
            header: 'Confirm Alert',
            subHeader: 'Beware lets confirm',
            message: 'Are you sure? you want to leave without safty mask?',
            buttons: [
                {
                    text: 'Never',
                    handler: () => {
                        console.log('I care about humanity');
                    }
                },
                {
                    text: 'Not Sure',
                    handler: () => {
                        console.log('Let me think');
                    }
                },
                {
                    text: 'Yes!',
                    handler: () => {
                        console.log('Whatever');
                    }
                }
            ]
        }).then(res => {
            res.present();
        });
    }
};
InputPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.AlertController }
];
InputPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-input',
        template: _raw_loader_input_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_input_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], InputPage);



/***/ }),

/***/ 9159:
/*!*********************************************!*\
  !*** ./src/app/pages/input/input.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".titulo {\n  font-size: 20px;\n  size: 5%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImlucHV0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGVBQUE7RUFDQSxRQUFBO0FBQ0oiLCJmaWxlIjoiaW5wdXQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRpdHVsb3tcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgc2l6ZTogNSU7XG59Il19 */");

/***/ }),

/***/ 6412:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/input/input.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n\n<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button \n          defaultHref=\"/\"\n          text=\"volver\"\n          color=\"primary\"\n          mode=\"ios\"></ion-back-button>\n    </ion-buttons>\n      <ion-title class=\"titulo\">Crear cuenta</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content>\n\n  <form #formulario=\"ngForm\" (ngSubmit) =\"onSubmit()\">\n\n  <ion-item>\n    <ion-label required position=\"stacked\">Nombre: </ion-label>\n    <ion-input type=\"input\" \n                 name=\"nombre\" [(ngModel)]= \"usuario.nombre\"\n                 required>\n      </ion-input>\n  </ion-item>\n\n  <ion-item>\n    <ion-label  required position=\"stacked\">Apellidos: </ion-label>\n    <ion-input type=\"input\" \n                 name=\"apellido\" [(ngModel)]= \"usuario.apellido\"\n                 required>\n      </ion-input>\n  </ion-item>\n\n\n  <ion-item>\n    <ion-label>Género</ion-label>\n    <ion-select [interfaceOptions]=\"customPopoverOptions\" interface=\"popover\" placeholder=\"Select One\" required \n    name=\"genero\" [(ngModel)]= \"usuario.genero\">\n      <ion-select-option value=\"brown\">Femenino</ion-select-option>\n      <ion-select-option value=\"blonde\">Masculino</ion-select-option>\n      <ion-select-option value=\"black\">Otro</ion-select-option>\n\n    </ion-select>\n  </ion-item>\n\n\n  \n\n  <ion-item>\n    <ion-label position=\"floating\">Fecha nacimiento</ion-label>\n    <ion-datetime displayFormat=\"D MMM YYYY\" min=\"1945\" max=\"2005\" placeholder=\"Seleccione su fecha\"\n    monthShortNames=\"enero, febrero, marzo, abril, mayo, junio, julio, agosto,\n     septiembre, agosto,octubre, noviembre, diciembre\"  name=\"fecha\" [(ngModel)]= \"usuario.fecha\" required ></ion-datetime>\n  </ion-item>\n\n\n\n    <ion-item>\n      <ion-label required position=\"stacked\">Email: </ion-label>\n      <ion-input type=\"email\" \n                 name=\"email\" [(ngModel)]= \"usuario.email\"\n                 pattern=\"^([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})$\"\n                 required>\n      </ion-input>\n    </ion-item>\n\n    <ion-item>\n      <ion-label required position=\"stacked\">Contraseña: </ion-label>\n      <ion-input type=\"password\" \n                 name=\"password\" [(ngModel)]= \"usuario.password\"\n                 required>\n      </ion-input>\n    </ion-item>\n\n    <ion-item>\n      <ion-label required position=\"stacked\">Confirmar contraseña: </ion-label>\n      <ion-input type=\"password\" \n                 name=\"password2\" [(ngModel)]= \"usuario.password2\"\n                 required>\n      </ion-input>\n    </ion-item>\n\n    <ion-button (click)=\"showAlert()\" [disabled] =\"formulario.invalid\"\n        type=\"submit\" expand=\"block\" routerLink=\"/inicio\" color=\"success\">\n      Enviar Datos\n    </ion-button>\n\n\n\n  \n\n\n  </form>\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_input_input_module_ts.js.map