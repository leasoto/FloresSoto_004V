(self["webpackChunkMyApp"] = self["webpackChunkMyApp"] || []).push([["src_app_task_task_module_ts"],{

/***/ 588:
/*!*********************************************!*\
  !*** ./src/app/task/task-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TaskPageRoutingModule": () => (/* binding */ TaskPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _task_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./task.page */ 3493);




const routes = [
    {
        path: '',
        component: _task_page__WEBPACK_IMPORTED_MODULE_0__.TaskPage
    }
];
let TaskPageRoutingModule = class TaskPageRoutingModule {
};
TaskPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], TaskPageRoutingModule);



/***/ }),

/***/ 3917:
/*!*************************************!*\
  !*** ./src/app/task/task.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TaskPageModule": () => (/* binding */ TaskPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _task_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./task-routing.module */ 588);
/* harmony import */ var _task_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./task.page */ 3493);







let TaskPageModule = class TaskPageModule {
};
TaskPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _task_routing_module__WEBPACK_IMPORTED_MODULE_0__.TaskPageRoutingModule
        ],
        declarations: [_task_page__WEBPACK_IMPORTED_MODULE_1__.TaskPage]
    })
], TaskPageModule);



/***/ }),

/***/ 3493:
/*!***********************************!*\
  !*** ./src/app/task/task.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TaskPage": () => (/* binding */ TaskPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_task_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./task.page.html */ 5190);
/* harmony import */ var _task_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./task.page.scss */ 5732);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);




let TaskPage = class TaskPage {
    constructor() { }
    ngOnInit() {
    }
};
TaskPage.ctorParameters = () => [];
TaskPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-task',
        template: _raw_loader_task_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_task_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], TaskPage);



/***/ }),

/***/ 5732:
/*!*************************************!*\
  !*** ./src/app/task/task.page.scss ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".subtitulo2 {\n  color: #912323;\n  font-family: \"Times New Roman\", Times, serif;\n  font-size: 40px;\n  font-weight: bold;\n}\n\n.titulo2 {\n  color: cadetblue;\n  font-family: \"Lucida Sans\", \"Lucida Sans Regular\", \"Lucida Grande\", \"Lucida Sans Unicode\", Geneva, Verdana, sans-serif;\n  font-size: 25px;\n  font-weight: normal;\n}\n\n.contenido {\n  text-align: justify;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRhc2sucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtFQUNBLDRDQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FBQ0o7O0FBRUE7RUFDSSxnQkFBQTtFQUNBLHNIQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0FBQ0o7O0FBRUE7RUFDSSxtQkFBQTtBQUNKIiwiZmlsZSI6InRhc2sucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnN1YnRpdHVsbzJ7XG4gICAgY29sb3I6IHJnYigxNDUsIDM1LCAzNSk7XG4gICAgZm9udC1mYW1pbHk6ICdUaW1lcyBOZXcgUm9tYW4nLCBUaW1lcywgc2VyaWY7XG4gICAgZm9udC1zaXplOiA0MHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuXG4udGl0dWxvMntcbiAgICBjb2xvcjogY2FkZXRibHVlO1xuICAgIGZvbnQtZmFtaWx5OiAnTHVjaWRhIFNhbnMnLCAnTHVjaWRhIFNhbnMgUmVndWxhcicsICdMdWNpZGEgR3JhbmRlJywgJ0x1Y2lkYSBTYW5zIFVuaWNvZGUnLCBHZW5ldmEsIFZlcmRhbmEsIHNhbnMtc2VyaWY7XG4gICAgZm9udC1zaXplOiAyNXB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG59XG5cbi5jb250ZW5pZG97XG4gICAgdGV4dC1hbGlnbjoganVzdGlmeTtcblxufSJdfQ== */");

/***/ }),

/***/ 5190:
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/task/task.page.html ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"end\">\n      <ion-avatar>\n        <ion-img src=\"/assets/zoro2.jfif\"></ion-img>\n      </ion-avatar>\n    </ion-buttons>\n    <ion-title>task</ion-title>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaulthref=\"/\" text=\"Back\" color =\"primary\" mode =\"ios\">\n\n      </ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-card>\n    <ion-card-header>\n      \n      <ion-card-subtitle class=\"subtitulo2\">One piece</ion-card-subtitle > \n      <ion-img src=\"/assets/onepiece.jpg\"></ion-img>\n      <ion-card-title class=\"titulo2\">El mejor anime del mundo</ion-card-title>\n    </ion-card-header>\n\n    <ion-card-content class=\"ion-pading-contenido\">\n      One Piece es una aventura de piratas. Es la historia de un chico llamado Monkey D. ... Luffy,\n       inspirado por el pirata Shanks \"Akagami\", sale al mar diez años después para convertirse \n       en el Rey de los Piratas. Para ello necesitaría encontrar una tripulación adecuada, \n      diez personas que lo acompañarían en su aventura.\n    </ion-card-content>\n\n  </ion-card>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_task_task_module_ts.js.map