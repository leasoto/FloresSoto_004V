(self["webpackChunkMyApp"] = self["webpackChunkMyApp"] || []).push([["src_app_pages_contaminacion_contaminacion_module_ts"],{

/***/ 1437:
/*!*********************************************************************!*\
  !*** ./src/app/pages/contaminacion/contaminacion-routing.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ContaminacionPageRoutingModule": () => (/* binding */ ContaminacionPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _contaminacion_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./contaminacion.page */ 9457);




const routes = [
    {
        path: '',
        component: _contaminacion_page__WEBPACK_IMPORTED_MODULE_0__.ContaminacionPage
    }
];
let ContaminacionPageRoutingModule = class ContaminacionPageRoutingModule {
};
ContaminacionPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ContaminacionPageRoutingModule);



/***/ }),

/***/ 4788:
/*!*************************************************************!*\
  !*** ./src/app/pages/contaminacion/contaminacion.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ContaminacionPageModule": () => (/* binding */ ContaminacionPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _contaminacion_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./contaminacion-routing.module */ 1437);
/* harmony import */ var _contaminacion_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./contaminacion.page */ 9457);







let ContaminacionPageModule = class ContaminacionPageModule {
};
ContaminacionPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _contaminacion_routing_module__WEBPACK_IMPORTED_MODULE_0__.ContaminacionPageRoutingModule
        ],
        declarations: [_contaminacion_page__WEBPACK_IMPORTED_MODULE_1__.ContaminacionPage]
    })
], ContaminacionPageModule);



/***/ }),

/***/ 9457:
/*!***********************************************************!*\
  !*** ./src/app/pages/contaminacion/contaminacion.page.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ContaminacionPage": () => (/* binding */ ContaminacionPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_contaminacion_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./contaminacion.page.html */ 8346);
/* harmony import */ var _contaminacion_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./contaminacion.page.scss */ 6427);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 476);





let ContaminacionPage = class ContaminacionPage {
    constructor(menuController) {
        this.menuController = menuController;
        this.componentes = [];
    }
    ngOnInit() {
    }
    mostrarMenu() {
        this.menuController.open('first');
    }
};
ContaminacionPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.MenuController }
];
ContaminacionPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-contaminacion',
        template: _raw_loader_contaminacion_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_contaminacion_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ContaminacionPage);



/***/ }),

/***/ 6427:
/*!*************************************************************!*\
  !*** ./src/app/pages/contaminacion/contaminacion.page.scss ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".logo {\n  width: 60%;\n  left: 0;\n  bottom: 0;\n  padding-left: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbnRhbWluYWNpb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUksVUFBQTtFQUNBLE9BQUE7RUFDQSxTQUFBO0VBQ0EsZUFBQTtBQUFKIiwiZmlsZSI6ImNvbnRhbWluYWNpb24ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmxvZ28ge1xuXG4gICAgd2lkdGg6IDYwJTtcbiAgICBsZWZ0OiAwO1xuICAgIGJvdHRvbTogMDtcbiAgICBwYWRkaW5nLWxlZnQ6IDA7XG4gIH0iXX0= */");

/***/ }),

/***/ 8346:
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/contaminacion/contaminacion.page.html ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar class=\"ion-toolbar\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaulthref=\"/\" text=\"volver\" color =\"primary\" mode =\"ios\">\n      </ion-back-button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"mostrarMenu()\">\n        <ion-icon slot=\"icon-only\" name=\"menu-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    \n    <ion-img class=\"logo\" src=\"/assets/logo3.jpeg\"></ion-img>\n  </ion-toolbar>\n  \n</ion-header>\n\n\n<ion-content>\n  <ion-card>\n    \n    <img src=\"assets/autoco2.jpg\"/>\n    <ion-card-content>\n      <ion-card-title>\n        ¿Qué es el Co2?\n      </ion-card-title>\n      <p>\n        En el medio ambiente, el dióxido de carbono \n        es la sustancia que más contribuye al efecto invernadero, es decir,\n         que absorbe gran parte de la radiación solar incidente, reteniéndola cerca de la superficie terrestre y produciendo una calentamiento progresivo de la misma.\n      </p>\n    </ion-card-content>\n\n    <ion-row no-padding>\n      <ion-col>\n        <button ion-button clear small color=\"danger\" icon-start>\n          <ion-icon name=\"star\"></ion-icon>\n          Favorite\n        </button>\n      </ion-col>\n\n      <ion-col text-right>\n        <button ion-button clear small color=\"danger\" icon-start>\n          <ion-icon name=\"share-social-outline\"></ion-icon>\n          Share\n        </button>\n      </ion-col>\n    </ion-row>\n\n  </ion-card>\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_contaminacion_contaminacion_module_ts.js.map