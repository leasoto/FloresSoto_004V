(self["webpackChunkMyApp"] = self["webpackChunkMyApp"] || []).push([["src_app_pages_login_login_module_ts"],{

/***/ 3403:
/*!*****************************************************!*\
  !*** ./src/app/pages/login/login-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageRoutingModule": () => (/* binding */ LoginPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.page */ 3058);




const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_0__.LoginPage
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], LoginPageRoutingModule);



/***/ }),

/***/ 1053:
/*!*********************************************!*\
  !*** ./src/app/pages/login/login.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageModule": () => (/* binding */ LoginPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login-routing.module */ 3403);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page */ 3058);







let LoginPageModule = class LoginPageModule {
};
LoginPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _login_routing_module__WEBPACK_IMPORTED_MODULE_0__.LoginPageRoutingModule
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_1__.LoginPage]
    })
], LoginPageModule);



/***/ }),

/***/ 3058:
/*!*******************************************!*\
  !*** ./src/app/pages/login/login.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPage": () => (/* binding */ LoginPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_login_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./login.page.html */ 1021);
/* harmony import */ var _login_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page.scss */ 8781);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var src_app_services_authservice_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/authservice.service */ 3958);
/* harmony import */ var src_app_services_servicedatos_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/servicedatos.service */ 8321);







let LoginPage = class LoginPage {
    constructor(storageService, navCtrl, plt, toastController, menuController, authService) {
        this.storageService = storageService;
        this.navCtrl = navCtrl;
        this.plt = plt;
        this.toastController = toastController;
        this.menuController = menuController;
        this.authService = authService;
        this.usuarios = [];
        this.newUsuarios = {};
        this.usuarioLogueado = false;
        this.plt.ready().then(() => {
            this.loadUsuarios();
        });
    }
    buscarUsuarios(nombre, contraseña) {
        this.storageService.buscarUsuario(nombre, contraseña);
    }
    ngOnInit() {
        this.usuarioLogueado = this.authService.isLoggedIn('');
        this.authService.changeLoginStatus$.subscribe((loggedStatus) => {
            this.usuarioLogueado = loggedStatus;
        });
    }
    mostrarMenu() {
        this.menuController.open('first');
    }
    logout() {
        this.authService.logout();
    }
    loadUsuarios() {
        this.storageService.getUsuarios().then(usuarios => {
            this.usuarios = usuarios;
        });
    }
    showToast(msg) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: msg,
                duration: 2000
            });
            toast.present();
        });
    }
};
LoginPage.ctorParameters = () => [
    { type: src_app_services_servicedatos_service__WEBPACK_IMPORTED_MODULE_3__.ServicedatosService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.Platform },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ToastController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.MenuController },
    { type: src_app_services_authservice_service__WEBPACK_IMPORTED_MODULE_2__.AuthService }
];
LoginPage.propDecorators = {
    myList: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['myList',] }]
};
LoginPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-login',
        template: _raw_loader_login_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_login_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], LoginPage);



/***/ }),

/***/ 8781:
/*!*********************************************!*\
  !*** ./src/app/pages/login/login.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".pass2 {\n  font-size: 12px;\n  size: 5%;\n}\n\n.cuenta {\n  font-size: 16px;\n  size: 5%;\n}\n\n.titulo {\n  font-size: 18px;\n  size: 5%;\n  padding-left: 75px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZ2luLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGVBQUE7RUFDQSxRQUFBO0FBQ0o7O0FBRUE7RUFDSSxlQUFBO0VBQ0EsUUFBQTtBQUNKOztBQUVBO0VBQ0ksZUFBQTtFQUNBLFFBQUE7RUFDQSxrQkFBQTtBQUNKIiwiZmlsZSI6ImxvZ2luLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5wYXNzMntcbiAgICBmb250LXNpemU6IDEycHg7XG4gICAgc2l6ZTogNSU7XG59XG5cbi5jdWVudGF7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIHNpemU6IDUlO1xufVxuXG4udGl0dWxve1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBzaXplOiA1JTtcbiAgICBwYWRkaW5nLWxlZnQ6IDc1cHg7XG4gICAgXG59Il19 */");

/***/ }),

/***/ 1021:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/login/login.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header >\n  <ion-scroll scrollX=\"false\">\n  </ion-scroll>\n  <ion-toolbar class=\"ion-toolbar\">\n\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"mostrarMenu()\">\n        <ion-icon slot=\"icon-only\" name=\"menu-outline\"></ion-icon>\n        \n      </ion-button>\n      \n    </ion-buttons>\n    <ion-img class=\"logo\" src=\"/assets/logo3.jpeg\"></ion-img>\n\n  </ion-toolbar>\n\n</ion-header>\n\n\n\n<ion-content>\n  <ion-button (click)=\"logout()\" *ngIf=\"usuarioLogueado\">\n    Log-out\n   </ion-button>\n  <form>\n    <ion-card-header>\n      <ion-card-title>Inicio de sesión</ion-card-title>\n    </ion-card-header>\n    <ion-card-content>\n\n      <form #formulario=\"ngForm\" (ngSubmit)=\"buscarUsuarios(newUsuarios.usuario,newUsuarios.contrasenia)\" *ngIf=\"!usuarioLogueado\">\n        <ion-item>\n          <ion-label>Usuario:</ion-label>\n          <ion-input type=\"text\" placeholder=\"Escriba su usuario\"\n                     name=\"Usuario\" [(ngModel)]=\"newUsuarios.usuario\"\n                     required></ion-input>\n        </ion-item>\n    \n        <ion-item>\n          <ion-label>Contraseña:</ion-label>\n          <ion-input type=\"password\" placeholder=\"Contraseña\"\n                     name=\"password\" [(ngModel)]=\"newUsuarios.contrasenia\"\n                     required\n                     minlength=\"0\"\n                     maxlength=\"15\"></ion-input>\n        </ion-item>\n        <ion-button [disabled]=\"formulario.invalid\" type=\"submit\" expand=\"block\" >\n    \n          Log-in\n          \n        </ion-button>\n      </form>\n      <br>\n    </ion-card-content>\n \n\n\n  <ion-row>\n    <ion-col>\n      <ion-col>\n        <center>\n      <a  routerLink=\"/login\" class=\"pass2\">¿Olvidaste tu contraseña?</a>\n      </center>\n      <br>\n      <center>\n        <a [routerLink]=\"['/registro']\" class=\"cuenta\">¿No Tienes cuenta?</a>\n      </center>\n    \n    </ion-col>\n    </ion-col>\n  </ion-row>\n</form>\n\n</ion-content>\n\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_login_login_module_ts.js.map