(self["webpackChunkMyApp"] = self["webpackChunkMyApp"] || []).push([["src_app_pages_modificar_modificar_module_ts"],{

/***/ 1141:
/*!*************************************************************!*\
  !*** ./src/app/pages/modificar/modificar-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModificarPageRoutingModule": () => (/* binding */ ModificarPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _modificar_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./modificar.page */ 6105);




const routes = [
    {
        path: '',
        component: _modificar_page__WEBPACK_IMPORTED_MODULE_0__.ModificarPage
    }
];
let ModificarPageRoutingModule = class ModificarPageRoutingModule {
};
ModificarPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ModificarPageRoutingModule);



/***/ }),

/***/ 3036:
/*!*****************************************************!*\
  !*** ./src/app/pages/modificar/modificar.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModificarPageModule": () => (/* binding */ ModificarPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _modificar_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./modificar-routing.module */ 1141);
/* harmony import */ var _modificar_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modificar.page */ 6105);







let ModificarPageModule = class ModificarPageModule {
};
ModificarPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _modificar_routing_module__WEBPACK_IMPORTED_MODULE_0__.ModificarPageRoutingModule
        ],
        declarations: [_modificar_page__WEBPACK_IMPORTED_MODULE_1__.ModificarPage]
    })
], ModificarPageModule);



/***/ }),

/***/ 6105:
/*!***************************************************!*\
  !*** ./src/app/pages/modificar/modificar.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModificarPage": () => (/* binding */ ModificarPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_modificar_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./modificar.page.html */ 2579);
/* harmony import */ var _modificar_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modificar.page.scss */ 6197);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var src_app_services_servicedatos_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/servicedatos.service */ 8321);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 476);







let ModificarPage = class ModificarPage {
    constructor(storageService, plt, toastController, alertController) {
        this.storageService = storageService;
        this.plt = plt;
        this.toastController = toastController;
        this.alertController = alertController;
        this.datos = [];
        this.newDato = {};
        this.plt.ready().then(() => {
            this.loadDatos();
        });
    }
    ngOnInit() {
    }
    //create
    addDatos() {
        this.newDato.modified = Date.now();
        this.newDato.id = Date.now();
        this.storageService.addDatos(this.newDato).then(dato => {
            this.newDato = {};
            this.showToast('!Datos Agregados');
            this.loadDatos();
        });
    }
    //get
    loadDatos() {
        this.storageService.getDatos().then(datos => {
            this.datos = datos;
        });
    }
    //update
    updateDatos(dato) {
        dato.patente = `UPDATED: ${dato.patente}`;
        dato.modified = Date.now();
        this.storageService.updateDatos(dato).then(item => {
            this.showToast('Elemento actualizado!');
            this.myList.closeSlidingItems();
            this.loadDatos();
        });
    }
    //delete
    deleteDatos(dato) {
        this.storageService.deleteDatos(dato.id).then(item => {
            this.showToast('Elemento eliminado');
            this.myList.closeSlidingItems();
            this.loadDatos();
        });
    }
    showToast(msg) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: msg,
                duration: 2000
            });
            toast.present();
        });
    }
    showConfirm() {
        this.alertController.create({
            header: 'Confirmar ',
            message: '¿Estás seguro que deseas eliminar?',
            buttons: [
                {
                    text: 'NO',
                },
                {
                    text: 'Si',
                    handler: () => {
                    }
                }
            ]
        }).then(res => {
            res.present();
        });
    }
};
ModificarPage.ctorParameters = () => [
    { type: src_app_services_servicedatos_service__WEBPACK_IMPORTED_MODULE_2__.ServicedatosService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.Platform },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ToastController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.AlertController }
];
ModificarPage.propDecorators = {
    myList: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.ViewChild, args: ['myList',] }]
};
ModificarPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-modificar',
        template: _raw_loader_modificar_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_modificar_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ModificarPage);



/***/ }),

/***/ 6197:
/*!*****************************************************!*\
  !*** ./src/app/pages/modificar/modificar.page.scss ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".logo {\n  width: 60%;\n  left: 0;\n  bottom: 0;\n  padding-left: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1vZGlmaWNhci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSxVQUFBO0VBQ0EsT0FBQTtFQUNBLFNBQUE7RUFDQSxlQUFBO0FBQUoiLCJmaWxlIjoibW9kaWZpY2FyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5sb2dvIHtcblxuICAgIHdpZHRoOiA2MCU7XG4gICAgbGVmdDogMDtcbiAgICBib3R0b206IDA7XG4gICAgcGFkZGluZy1sZWZ0OiAwO1xuICB9Il19 */");

/***/ }),

/***/ 2579:
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/modificar/modificar.page.html ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"volver\" color =\"primary\" mode =\"ios\"> </ion-back-button>\n    </ion-buttons>\n    <ion-row>\n    <center>\n    <ion-title >Listado</ion-title>\n  </center>\n  </ion-row>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-list #myList>\n\n\n    <ion-list>\n      <ion-item-sliding *ngFor=\"let dato of datos\">\n        <ion-item>\n          <ion-label text-wrap> \n            <h3>{{dato.patente}}</h3>\n            <ion-text color=\"secondary\">\n              <p>{{dato.modelo}}</p>\n            </ion-text>\n            <p>{{dato.modified | date: 'short'}}</p>\n          </ion-label>\n        </ion-item>\n        <ion-item-buttons side=\"end\">\n          <ion-button color=\"secondary\" (click)=\"updateDatos(dato)\" (click)=\"showConfirm()\">Actualizar</ion-button>\n         <ion-button color=\"danger\" (click)=\"deleteDatos(dato)\"  routerLink = \"/modificar\" >Eliminar</ion-button> \n        </ion-item-buttons>\n      </ion-item-sliding>\n    </ion-list>\n  </ion-list>\n</ion-content>\n\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_modificar_modificar_module_ts.js.map