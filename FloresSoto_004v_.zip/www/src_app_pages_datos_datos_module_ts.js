(self["webpackChunkMyApp"] = self["webpackChunkMyApp"] || []).push([["src_app_pages_datos_datos_module_ts"],{

/***/ 7169:
/*!*****************************************************!*\
  !*** ./src/app/pages/datos/datos-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DatosPageRoutingModule": () => (/* binding */ DatosPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _datos_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./datos.page */ 5864);




const routes = [
    {
        path: '',
        component: _datos_page__WEBPACK_IMPORTED_MODULE_0__.DatosPage
    }
];
let DatosPageRoutingModule = class DatosPageRoutingModule {
};
DatosPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DatosPageRoutingModule);



/***/ }),

/***/ 1048:
/*!*********************************************!*\
  !*** ./src/app/pages/datos/datos.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DatosPageModule": () => (/* binding */ DatosPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _datos_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./datos-routing.module */ 7169);
/* harmony import */ var _datos_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./datos.page */ 5864);







let DatosPageModule = class DatosPageModule {
};
DatosPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _datos_routing_module__WEBPACK_IMPORTED_MODULE_0__.DatosPageRoutingModule
        ],
        declarations: [_datos_page__WEBPACK_IMPORTED_MODULE_1__.DatosPage]
    })
], DatosPageModule);



/***/ }),

/***/ 5864:
/*!*******************************************!*\
  !*** ./src/app/pages/datos/datos.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DatosPage": () => (/* binding */ DatosPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_datos_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./datos.page.html */ 6062);
/* harmony import */ var _datos_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./datos.page.scss */ 887);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var src_app_services_servicedatos_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/servicedatos.service */ 8321);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 476);






let DatosPage = class DatosPage {
    constructor(storageService, plt, toastController) {
        this.storageService = storageService;
        this.plt = plt;
        this.toastController = toastController;
        this.datos = [];
        this.newDato = {};
        this.plt.ready().then(() => {
            this.loadDatos();
        });
    }
    ngOnInit() {
    }
    //get
    loadDatos() {
        this.storageService.getDatos().then(datos => {
            this.datos = datos;
        });
    }
    //create
    addDatos() {
        this.newDato.modified = Date.now();
        this.newDato.id = Date.now();
        this.storageService.addDatos(this.newDato).then(dato => {
            this.newDato = {};
            this.showToast('!Datos Agregados');
            this.loadDatos();
        });
    }
    //update
    updateDatos(dato) {
        dato.patente = `UPDATED: ${dato.patente}`;
        dato.modified = Date.now();
        this.storageService.updateDatos(dato).then(item => {
            this.showToast('Elemento actualizado!');
            this.myList.closeSlidingItems();
            this.loadDatos();
        });
    }
    //delete
    deleteDatos(dato) {
        this.storageService.deleteDatos(dato.id).then(item => {
            this.showToast('Elemento eliminado');
            this.myList.closeSlidingItems();
            this.loadDatos();
        });
    }
    showToast(msg) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: msg,
                duration: 2000
            });
            toast.present();
        });
    }
};
DatosPage.ctorParameters = () => [
    { type: src_app_services_servicedatos_service__WEBPACK_IMPORTED_MODULE_2__.ServicedatosService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.Platform },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ToastController }
];
DatosPage.propDecorators = {
    myList: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.ViewChild, args: ['myList',] }]
};
DatosPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-datos',
        template: _raw_loader_datos_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_datos_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], DatosPage);



/***/ }),

/***/ 887:
/*!*********************************************!*\
  !*** ./src/app/pages/datos/datos.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkYXRvcy5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ 6062:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/datos/datos.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"volver\" color =\"primary\" mode =\"ios\"> </ion-back-button>\n    </ion-buttons>\n    <ion-row>\n    <center>\n    <ion-title >Ingresar vehículos</ion-title>\n  </center>\n  </ion-row>\n  </ion-toolbar>\n</ion-header>\n\n\n\n\n<ion-content>\n  <ion-item>\n    <ion-label position=\"stacked\">Patente</ion-label>\n    <ion-input type=\"text\" [(ngModel)]=\"newDato.patente\" required></ion-input>\n  </ion-item>\n\n  <ion-item>\n    <ion-label position=\"stacked\">Modelo vehículo</ion-label>\n    <ion-input type=\"text\" [(ngModel)]=\"newDato.modelo\" required></ion-input>\n  </ion-item>\n  \n  <ion-item>\n    <ion-label position=\"stacked\">Nombre dueño</ion-label>\n    <ion-input type=\"text\" [(ngModel)]=\"newDato.edad\" required></ion-input>\n  </ion-item>\n  <ion-item>\n    <ion-label position=\"stacked\">Huella</ion-label>\n    <ion-input type=\"text\" [(ngModel)]=\"newDato.huella\" required></ion-input>\n  </ion-item>\n\n  <ion-button (click)=\"addDatos()\" expand=\"full\">\n    Ingresar vehículo\n  </ion-button>\n\n  <ion-button (click)=\"addDatos()\" expand=\"full\" routerLink = \"/modificar\">\n    Ver listado de vehículos\n  </ion-button>\n  <ion-list #myList>\n\n  </ion-list>\n</ion-content>\n\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_datos_datos_module_ts.js.map