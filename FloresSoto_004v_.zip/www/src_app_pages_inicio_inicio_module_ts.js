(self["webpackChunkMyApp"] = self["webpackChunkMyApp"] || []).push([["src_app_pages_inicio_inicio_module_ts"],{

/***/ 5652:
/*!*******************************************************!*\
  !*** ./src/app/pages/inicio/inicio-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InicioPageRoutingModule": () => (/* binding */ InicioPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _inicio_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./inicio.page */ 5237);




const routes = [
    {
        path: '',
        component: _inicio_page__WEBPACK_IMPORTED_MODULE_0__.InicioPage
    }
];
let InicioPageRoutingModule = class InicioPageRoutingModule {
};
InicioPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], InicioPageRoutingModule);



/***/ }),

/***/ 3633:
/*!***********************************************!*\
  !*** ./src/app/pages/inicio/inicio.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InicioPageModule": () => (/* binding */ InicioPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _inicio_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./inicio-routing.module */ 5652);
/* harmony import */ var _inicio_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./inicio.page */ 5237);







let InicioPageModule = class InicioPageModule {
};
InicioPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _inicio_routing_module__WEBPACK_IMPORTED_MODULE_0__.InicioPageRoutingModule
        ],
        declarations: [_inicio_page__WEBPACK_IMPORTED_MODULE_1__.InicioPage]
    })
], InicioPageModule);



/***/ }),

/***/ 5237:
/*!*********************************************!*\
  !*** ./src/app/pages/inicio/inicio.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InicioPage": () => (/* binding */ InicioPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_inicio_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./inicio.page.html */ 2531);
/* harmony import */ var _inicio_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./inicio.page.scss */ 583);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 476);





let InicioPage = class InicioPage {
    constructor(menuController) {
        this.menuController = menuController;
        this.componentes = [
            {
                icon: 'beer',
                name: 'cerveza',
                redirectTo: '/alert'
            },
            {
                icon: 'beer',
                name: 'cerveza',
                redirectTo: '/action-sheet'
            },
            {
                icon: 'beer',
                name: 'input',
                redirectTo: '/input'
            },
            {
                icon: 'beer',
                name: 'autos',
                redirectTo: '/autos'
            },
            {
                icon: 'beer',
                name: 'noticias',
                redirectTo: '/noticias'
            }
        ];
    }
    ngOnInit() {
    }
    mostrarMenu() {
        this.menuController.open('first');
    }
};
InicioPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.MenuController }
];
InicioPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-inicio',
        template: _raw_loader_inicio_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_inicio_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], InicioPage);



/***/ }),

/***/ 583:
/*!***********************************************!*\
  !*** ./src/app/pages/inicio/inicio.page.scss ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".logo {\n  width: 60%;\n  left: 0;\n  bottom: 0;\n  padding-left: 0;\n}\n\n.ion-toolbar {\n  height: 70px;\n}\n\n.button1 {\n  width: 60px;\n  height: 60px;\n  margin-top: 25px;\n  margin-left: 20px;\n}\n\n.button2 {\n  width: 60px;\n  height: 60px;\n  margin-top: 25px;\n  margin-left: 10px;\n  align-items: center;\n}\n\n.button3 {\n  width: 60px;\n  height: 60px;\n  margin-top: 25px;\n  margin-left: 5px;\n  align-items: center;\n}\n\n.letraboton {\n  font-size: 10px;\n  size: 5%;\n}\n\n.letraboton2 {\n  font-size: 10px;\n  size: 5%;\n  margin-left: 8px;\n}\n\n.letraboton3 {\n  font-size: 9px;\n  size: 5%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluaWNpby5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSxVQUFBO0VBQ0EsT0FBQTtFQUNBLFNBQUE7RUFDQSxlQUFBO0FBQUo7O0FBR0E7RUFDSSxZQUFBO0FBQUo7O0FBSUU7RUFFRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUFGSjs7QUFLRTtFQUVFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0FBSEo7O0FBS0U7RUFFRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtBQUhKOztBQU9FO0VBQ0UsZUFBQTtFQUNBLFFBQUE7QUFKSjs7QUFPRTtFQUNFLGVBQUE7RUFDQSxRQUFBO0VBQ0EsZ0JBQUE7QUFKSjs7QUFRRTtFQUNFLGNBQUE7RUFDQSxRQUFBO0FBTEoiLCJmaWxlIjoiaW5pY2lvLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5sb2dvIHtcblxuICAgIHdpZHRoOiA2MCU7XG4gICAgbGVmdDogMDtcbiAgICBib3R0b206IDA7XG4gICAgcGFkZGluZy1sZWZ0OiAwO1xuICB9XG5cbi5pb24tdG9vbGJhcntcbiAgICBoZWlnaHQ6NzBweDtcbiAgfVxuXG5cbiAgLmJ1dHRvbjEge1xuXG4gICAgd2lkdGg6IDYwcHg7XG4gICAgaGVpZ2h0OiA2MHB4O1xuICAgIG1hcmdpbi10b3A6IDI1cHg7XG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XG4gIH1cblxuICAuYnV0dG9uMiB7XG5cbiAgICB3aWR0aDogNjBweDtcbiAgICBoZWlnaHQ6IDYwcHg7XG4gICAgbWFyZ2luLXRvcDogMjVweDtcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICB9XG4gIC5idXR0b24zIHtcblxuICAgIHdpZHRoOiA2MHB4O1xuICAgIGhlaWdodDogNjBweDtcbiAgICBtYXJnaW4tdG9wOiAyNXB4O1xuICAgIG1hcmdpbi1sZWZ0OiA1cHg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgfVxuXG5cbiAgLmxldHJhYm90b257XG4gICAgZm9udC1zaXplOiAxMHB4O1xuICAgIHNpemU6IDUlO1xuXG4gIH1cbiAgLmxldHJhYm90b24ye1xuICAgIGZvbnQtc2l6ZTogMTBweDtcbiAgICBzaXplOiA1JTtcbiAgICBtYXJnaW4tbGVmdDogOHB4O1xuICB9XG5cbiAgXG4gIC5sZXRyYWJvdG9uM3tcbiAgICBmb250LXNpemU6IDlweDtcbiAgICBzaXplOiA1JTtcblxuICB9Il19 */");

/***/ }),

/***/ 2531:
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/inicio/inicio.page.html ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header >\n  <ion-scroll scrollX=\"false\">\n  </ion-scroll>\n  <ion-toolbar class=\"ion-toolbar\">\n\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"mostrarMenu()\">\n        <ion-icon slot=\"icon-only\" name=\"menu-outline\"></ion-icon>\n        \n      </ion-button>\n      \n    </ion-buttons>\n    <ion-img class=\"logo\" src=\"/assets/logo3.jpeg\"></ion-img>\n\n  </ion-toolbar>\n\n</ion-header>\n\n\n<ion-content [scrollEvents]=\"false\">\n\n  <!--\n<ion-button routerLink = \"/alert\">\n  alert\n</ion-button>\n<ion-button routerLink = \"/action-sheet\">\n  action-sheet\n</ion-button>\n<ion-button routerLink = \"/task\">\n  task\n</ion-button>\n<ion-button routerLink = \"/input\">\n  input\n</ion-button>\n\n-->\n\n\n\n<ion-row>\n  <ion-col>\n    <ion-fab-button class=\"button1\" routerLink = \"/contaminacion\" color=\"light\" >\n      <ion-icon class=\"co2inicio\" name=\"leaf-outline\" ></ion-icon>\n    </ion-fab-button>\n\n    <ion-text class=\"letraboton2\">¿Qué es el Co2?</ion-text>\n\n  </ion-col>\n\n  <ion-col>\n  <ion-fab-button class=\"button2\"routerLink = \"/autos\" color=\"light\">\n    <ion-icon class=\"co2inicio\" name=\"car-sport-outline\" ></ion-icon>\n  </ion-fab-button>\n  <center>\n  <ion-text class=\"letraboton\">Conoce los vehículos</ion-text>\n  </center>\n  </ion-col>\n\n<ion-col>\n<ion-fab-button class=\"button3\" routerLink = \"/noticias\" color=\"light\" >\n  <ion-icon class=\"co2inicio\" name=\"earth-outline\" ></ion-icon>\n</ion-fab-button>\n<center>\n<ion-text class=\"letraboton3\">Últimas noticias</ion-text>\n</center>\n</ion-col>\n</ion-row>\n\n\n\n\n  <ion-card>\n    <ion-card-header>\n      \n      <ion-card-subtitle class=\"subtitulo2\">Un poco de nosotros</ion-card-subtitle > \n      <ion-img src=\"/assets/ecofriendly.jpg\"></ion-img>\n      <ion-card-title class=\"titulo2\" color=\"success\">¿Qué es TransLife? </ion-card-title>\n    </ion-card-header>\n\n    <ion-card-content class=\"ion-pading-contenido\">\n      TransLife es un aplicativo que está pensado para medir la huella \n      de carbono de aquellas empresas que generan servicios de mantención \n      de vehículos, la cual de acuerdo a la marca, modelo, año y tipo de\n       servicios, nos mostrara las toneladas de CO2 emitidas al final de \n       ciclo y las medidas de mitigación hacia el medio ambiente.\n    </ion-card-content>\n\n  </ion-card>\n\n  \n\n\n</ion-content>\n\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_inicio_inicio_module_ts.js.map