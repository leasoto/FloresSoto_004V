(self["webpackChunkMyApp"] = self["webpackChunkMyApp"] || []).push([["src_app_pages_action-sheet_action-sheet_module_ts"],{

/***/ 5098:
/*!*******************************************************************!*\
  !*** ./src/app/pages/action-sheet/action-sheet-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ActionSheetPageRoutingModule": () => (/* binding */ ActionSheetPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _action_sheet_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./action-sheet.page */ 4379);




const routes = [
    {
        path: '',
        component: _action_sheet_page__WEBPACK_IMPORTED_MODULE_0__.ActionSheetPage
    }
];
let ActionSheetPageRoutingModule = class ActionSheetPageRoutingModule {
};
ActionSheetPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ActionSheetPageRoutingModule);



/***/ }),

/***/ 4922:
/*!***********************************************************!*\
  !*** ./src/app/pages/action-sheet/action-sheet.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ActionSheetPageModule": () => (/* binding */ ActionSheetPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _action_sheet_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./action-sheet-routing.module */ 5098);
/* harmony import */ var _action_sheet_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./action-sheet.page */ 4379);







let ActionSheetPageModule = class ActionSheetPageModule {
};
ActionSheetPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _action_sheet_routing_module__WEBPACK_IMPORTED_MODULE_0__.ActionSheetPageRoutingModule
        ],
        declarations: [_action_sheet_page__WEBPACK_IMPORTED_MODULE_1__.ActionSheetPage]
    })
], ActionSheetPageModule);



/***/ }),

/***/ 4379:
/*!*********************************************************!*\
  !*** ./src/app/pages/action-sheet/action-sheet.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ActionSheetPage": () => (/* binding */ ActionSheetPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_action_sheet_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./action-sheet.page.html */ 9527);
/* harmony import */ var _action_sheet_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./action-sheet.page.scss */ 7633);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);




let ActionSheetPage = class ActionSheetPage {
    constructor() { }
    ngOnInit() {
    }
};
ActionSheetPage.ctorParameters = () => [];
ActionSheetPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-action-sheet',
        template: _raw_loader_action_sheet_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_action_sheet_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ActionSheetPage);



/***/ }),

/***/ 7633:
/*!***********************************************************!*\
  !*** ./src/app/pages/action-sheet/action-sheet.page.scss ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".subtitulo {\n  color: black;\n  font-family: \"Courier New\", Courier, monospace;\n  font-size: 20px;\n  font-weight: bold;\n}\n\n.titulo {\n  color: cadetblue;\n  font-family: \"Lucida Sans\", \"Lucida Sans Regular\", \"Lucida Grande\", \"Lucida Sans Unicode\", Geneva, Verdana, sans-serif;\n  font-size: 25px;\n  font-weight: normal;\n}\n\n.contenido {\n  text-align: justify;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFjdGlvbi1zaGVldC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxZQUFBO0VBQ0EsOENBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUFDSjs7QUFFQTtFQUNJLGdCQUFBO0VBQ0Esc0hBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7QUFDSjs7QUFFQTtFQUNJLG1CQUFBO0FBQ0oiLCJmaWxlIjoiYWN0aW9uLXNoZWV0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zdWJ0aXR1bG97XG4gICAgY29sb3I6IGJsYWNrO1xuICAgIGZvbnQtZmFtaWx5OiAnQ291cmllciBOZXcnLCBDb3VyaWVyLCBtb25vc3BhY2U7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuXG4udGl0dWxve1xuICAgIGNvbG9yOiBjYWRldGJsdWU7XG4gICAgZm9udC1mYW1pbHk6ICdMdWNpZGEgU2FucycsICdMdWNpZGEgU2FucyBSZWd1bGFyJywgJ0x1Y2lkYSBHcmFuZGUnLCAnTHVjaWRhIFNhbnMgVW5pY29kZScsIEdlbmV2YSwgVmVyZGFuYSwgc2Fucy1zZXJpZjtcbiAgICBmb250LXNpemU6IDI1cHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbn1cblxuLmNvbnRlbmlkb3tcbiAgICB0ZXh0LWFsaWduOiBqdXN0aWZ5O1xuXG59Il19 */");

/***/ }),

/***/ 9527:
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/action-sheet/action-sheet.page.html ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaulthref=\"/\" text=\"Back\" color =\"primary\" mode =\"ios\">\n\n      </ion-back-button>\n    </ion-buttons>\n    <ion-title>action-sheet</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n    <ion-card>\n      <ion-card-header>\n        \n        <ion-card-subtitle class=\"subtitulo\">One piece</ion-card-subtitle > \n        <ion-img src=\"/assets//icon/bandera2.png\"></ion-img>\n        <ion-card-title class=\"titulo\">The best anime ever</ion-card-title>\n      </ion-card-header>\n\n      <ion-card-content class=\"ion-pading-contenido\">\n        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dicta beatae similique in incidunt vitae! Sint autem culpa ab, quas sequi explicabo aliquam a eius blanditiis consectetur provident ipsum quaerat facere! Inventore provident sed commodi quisquam repudiandae officia tempora dignissimos vitae, cupiditate dolorum quidem placeat rem ex aliquid sequi blanditiis sapiente.\n      </ion-card-content>\n\n    </ion-card>\n    <ion-card>\n      <ion-item href=\"http://www.google.cl\" target=\"_blank\">\n        <ion-icon name=\"wifi\" slot=\"start\"></ion-icon>\n        <ion-label>Card Link Item 1 activated</ion-label>\n      </ion-item>\n    \n      <ion-item href=\"http://www.youtube.com\" target=\"_blank\">\n        <ion-icon name=\"wine\" slot=\"start\"></ion-icon>\n        <ion-label>Card Link Item 2</ion-label>\n      </ion-item>\n    \n\n    </ion-card>\n\n\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_action-sheet_action-sheet_module_ts.js.map