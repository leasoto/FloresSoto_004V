export const environment = {
  production: true,
  apiKey: '4ea88169115f494e882a627d0258da08'
};
